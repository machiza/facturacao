<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use Artisan;
use Auth;
use Session;
use DB;

class CronController extends Controller
{
    
	 public function index()
    { 
    	//return 'no cron jobs to run';
    	 Artisan::call('db:seed');
    	// Artisan::call('db:seed --class=BankAccountTypeTableSeeder');

    	return 'done';
  
   	} 	

    public function setup()
    { 
      //bill_v8e

		//setUp
    	/*
    	$user = array(
                'email'=>'demo@n3.co.mz',
                'password'=>'$2y$10$GbgX0Z2DGHOJIWAkFbkXaOPGH1Fu8QBqktctseholx3RLlKHGM/Y6',
                'real_name'=>'Admin',
                'role_id'=>1,
                'inactive'=>0,
                'remember_token'=>'XbPj4olmc87dlLBoQL2e3v9LJc23EEnoRAI5Pfv8MnGEUFq0ZYpaZAd5JuaW'
        );
       // DB::table('users')->truncate();
		DB::table('users')->insert($user);
		*/


    	$permissao=DB::select('select * from permissions where name=:nome',['nome'=>'update_version']);
    	if($permissao==null){
    		DB::insert('insert into permissions (id, name,display_name,description ) values (?, ?,?,?)', [114, 'update_version','Update version','Update version']);
    		DB::insert('insert into permission_role (permission_id, role_id) values (?, ?)', [114, 1]);	
		
		}


		$versao=DB::select('select * from preference where  value=:valor ',['valor'=>'1.1.3']);
		if($versao==null){
						
		DB::table('migrations')->truncate();
		Artisan::call('migrate');


		DB::insert('insert into preference (id, category,field,value ) values (?, ?,?,?)', [21, 'preference','version','1.1.3']);
		DB::insert('insert into preference (id, category,field,value ) values (?, ?,?,?)', [22, 'preference','date_version','14062018']);


		DB::update("update cust_branch set billing_country_id = 'MZ' where cust_branch.branch_code > ?", [0]);	

		DB::table('sales_order_details')
            ->whereNull('tipo_operacao')
            ->update(['tipo_operacao' => '']);

		//update CC table
		$contas=DB::table('sales_cc')
		         ->select('sales_cc.*')->get();

		foreach($contas as $dados){
		 	$linha=explode('-',$dados->reference_doc);
			if($linha[0]=='NC'){
				DB::table('sales_cc')->where('idcc', $dados->idcc)->update(['debito_credito' => 0]);
			}else{
				DB::table('sales_cc')->where('idcc', $dados->idcc)->update(['debito_credito' => 1]);
			}
			if($linha[0]=='RE'){
				DB::table('sales_cc')->where('idcc', $dados->idcc)->update(['payment_type_id_doc' => 2]);
			}
			
			
		}

		\Session::flash('success',trans('Actualizado com suesso para a versao 1.1.3 '));
		// return redirect()->intended('customer/list');
		return redirect()->intended('update/version');

		/* See the changes
		Auth::logout();
        \Session::flush();
		*/
    	

	}else{



		\Session::flash('success',trans('versao ja actualizada 1.1.3 '));
				// return redirect()->intended('customer/list');
				return redirect()->intended('update/version');
				
	}				

    }








    public function update_version()
    { 
    	$data['menu'] = 'setting';
        $data['sub_menu'] = 'general';
        $data['list_menu'] = 'update_version';
        $data['emailConfigData'] = DB::table('email_config')->first();
        //d($data['emailConfigData'],1);
        return view('admin.setting.updateSystem',$data);
    
	}




	public function force()
    { 
    /*	DB::table('migrations')->truncate();
		Artisan::call('migrate');
		
		$itemTaxTypes = [
            array('name' => 'Insent','tax_rate'=>0, 'defaults' => 0),
            array('name' => 'Normal 17%','tax_rate'=>17, 'defaults' => 1),
            array('name' => 'Purchases Tax','tax_rate'=>15,'defaults' => 0),
            array('name' => 'Normal','tax_rate'=>5, 'defaults' => 0)
        ];

        DB::table('item_tax_types')->truncate();
		DB::table('item_tax_types')->insert($itemTaxTypes);
	*/
		
		//actualizacao das contas correntes
	   //$correntes= DB::select("select * from sales_cc ");

		$contas=DB::table('sales_cc')
		         ->select('sales_cc.*')->get();


		foreach($contas as $dados){
		  
		    $linha=explode('-',$dados->reference_doc);

			if($linha[0]=='NC'){
				DB::table('sales_cc')->where('idcc', $dados->idcc)->update(['debito_credito' => 0]);
			}else{
				DB::table('sales_cc')->where('idcc', $dados->idcc)->update(['debito_credito' => 1]);
			}
			
		}
	

		//DB::insert('insert into preference (id, category,field,value ) values (?, ?,?,?)', [21, 'preference','version','1.1.0']);
		//DB::insert('insert into preference (id, category,field,value ) values (?, ?,?,?)', [22, 'preference','date_version','21042018']);


		//DB::update("update cust_branch set billing_country_id = 'MZ' where cust_branch.branch_code > ?", [0]);	

		\Session::flash('success',trans('Actualizado com suesso para a versao 1.1.0 '));
		// return redirect()->intended('customer/list');
		return redirect()->intended('update/version');
    }


    



}
