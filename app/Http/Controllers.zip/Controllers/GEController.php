<?php

namespace App\Http\Controllers;

use App\Model\GuiaEntrega;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use PDF;
use App\Http\Start\Helpers;

class GEController extends Controller
{
    public function __construct(GuiaEntrega $entrega){
     /**
     * Set the database connection. reference app\helper.php
     */   
        //selectDatabase();
        $this->sale = $entrega;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_guia_entrega';

        $data['guias'] = DB::table('sales_ge')
        ->leftjoin('debtors_master','sales_ge.debtor_no_ge','=','debtors_master.debtor_no')
       ->select("sales_ge.*","debtors_master.*")->orderBy('ge_no', 'desc')
        ->get();


        return view('admin.sale.sales_guia_entrega', $data);
    }



    public function create(){
    	$data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_guia_entrega';
        $data['customerData'] = DB::table('debtors_master')->where(['inactive'=>0])->where('status_debtor','!=','desactivo')->get();
        $invoice_count = DB::table('sales_ge')->count();
        if($invoice_count>0){
        $invoiceReference = DB::table('sales_ge')->select('reference_ge')->orderBy('ge_no','DESC')->first();

        $ref = explode("-",$invoiceReference->reference_ge);
        $data['invoice_count'] = (int) $ref[1];
        }else{
            $data['invoice_count'] = 0 ;
        }

        //new:
        $data['salesType'] = DB::table('sales_types')->select('sales_type','id')->get(); 
        
        $taxTypeList = DB::table('item_tax_types')->get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        
        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='".$value->id."' taxrate='".$value->tax_rate."'>".$value->name.'('.$value->tax_rate.')'."</option>";          
        }
        $data['tax_type'] = $selectStart.$taxOptions.$selectEnd;
        $data['tax_type_custom'] = $selectStartCustom.$taxOptions.$selectEndCustom;
        //end new

    	return view('admin.sale.guiaentrega_add', $data);
    }



    public function store(Request $request)
    {
        $userId = \Auth::user()->id;
        $this->validate($request, [
            'debtor_no' => 'required',
            'local_entrega' => 'required',
        ]);

        $itemQuantity = $request->item_quantity;        
        $itemIds = $request->item_id;
        $itemDiscount = $request->discount;
        $taxIds = $request->tax_id;
        $unitPrice = $request->unit_price;
        $stock_id = $request->stock_id;
        $description = $request->description;

        require_once './conexao.php';

        $ge_ref = $_POST["ge_ref"];
        $grandtotal = $_POST["total"];
        $debtor_no = $_POST["debtor_no"];     
        $local_entrega = $_POST["local_entrega"];
        $motorista = $_POST["motorista"];
        $carta = $_POST["carta"];
        $matricula= $_POST["matricula"];
        $data = $_POST["ge_date"];
        $data1 = substr($data, 0, 2);
        $data2 = substr($data, 3, 2);
        $data3 = substr($data, 6, 4);
        if($data1 > 10){
            $data_final = $data3."-". + $data2."-". + $data1; 
        }else{
            $data_final = $data3."-". + $data2."-0". + $data1;
        }
        $comment= $_POST["comments"];

        $sql = "insert into sales_ge (reference_ge, total, ge_date, local_entrega, motorista, carta, matricula, debtor_no_ge, branch_id, comments) values (:reference_ge, :total, :ge_date, :local_entrega, :motorista, :carta, :matricula, :debtor_no_ge, :branch_id,:comments)";
        $comando = $pdo->prepare($sql);
        $comando->bindParam(":reference_ge", $ge_ref);
        $comando->bindParam(":total", $grandtotal);
        $comando->bindParam(":ge_date", $data_final);
        $comando->bindParam(":local_entrega", $local_entrega);        
        $comando->bindParam(":motorista", $motorista);
        $comando->bindParam(":carta", $carta);
        $comando->bindParam(":matricula", $matricula);
        $comando->bindParam(":debtor_no_ge", $debtor_no);
        $comando->bindParam(":branch_id", $debtor_no);
        $comando->bindParam(":comments", $comment);
        if($comando->execute()){
            $last_id = $pdo->lastInsertId();


        // Inventory Items Start
        if(!empty($description)){
            foreach ($description as $key => $item) {
            // create salesOrderDetail Start
            $salesOrderDetail['ge_no_id'] = $last_id;
            //$salesOrderDetail['stock_id'] = $stock_id[$key];
            $salesOrderDetail['description'] = $item;
            $salesOrderDetail['quantity'] = $itemQuantity[$key];
            $salesOrderDetail['trans_type'] = SALESORDER;
            $salesOrderDetail['discount_percent'] = $itemDiscount[$key];
            $salesOrderDetail['tax_type_id'] = $taxIds[$key];
            $salesOrderDetail['unit_price'] = $unitPrice[$key];
            $salesOrderDetail['is_inventory'] = 1;
            DB::table('sales_ge_details')->insertGetId($salesOrderDetail);           
            }
        }
            // Inventory Items End

        // Custom items
        $tax_id_custom = $request->tax_id_custom;
        $custom_items_discount = $request->custom_items_discount;
        $custom_items_name = $request->custom_items_name;
        $custom_items_rate = $request->custom_items_rate;
        $custom_items_qty  = $request->custom_items_qty;
        $custom_items_amount = $request->custom_items_amount;
       // d($custom_items_name,1);
        if(!empty($custom_items_name)){
          
            foreach ($custom_items_name as $key=>$value) {
                // custom item order detail
               $itemsOrder['ge_no_id'] = $last_id;
               $itemsOrder['trans_type'] = SALESORDER;
               $itemsOrder['tax_type_id'] = $tax_id_custom[$key];
               $itemsOrder['discount_percent'] = $custom_items_discount[$key];
               $itemsOrder['description'] = $custom_items_name[$key];
               $itemsOrder['unit_price'] = $custom_items_rate[$key];
               $itemsOrder['quantity'] = $custom_items_qty[$key];
               $itemsOrder['is_inventory'] = 0;
               DB::table('sales_ge_details')->insert($itemsOrder);
            }
       }

            $last_id = $pdo->lastInsertId();
            \Session::flash('success',trans('message.success.save_success'));
            return redirect()->intended('sales/view_detail_ge/'.$last_id);
        }

    }

    public function viewGe($ge_no){
        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_guia_entrega';
        $data['invoiceData'] = DB::table('sales_ge')
                            ->where('ge_no', '=', $ge_no)
                            ->select("sales_ge.*")
                            ->first();

        $data['customerInfo']  = DB::table('sales_ge')
                             ->where('sales_ge.ge_no',$ge_no)
                             ->leftjoin('debtors_master','debtors_master.debtor_no','=','sales_ge.debtor_no_ge')
                             ->leftjoin('cust_branch','cust_branch.branch_code','=','sales_ge.branch_id')
                             ->leftjoin('countries','countries.id','=','cust_branch.shipping_country_id')
                             ->select('debtors_master.debtor_no','debtors_master.name','debtors_master.phone','debtors_master.email','cust_branch.br_name','cust_branch.br_address','cust_branch.billing_street','cust_branch.billing_city','cust_branch.billing_state','cust_branch.billing_zip_code','countries.country','cust_branch.billing_country_id')                            
                             ->first();
        return view('admin.sale.view_detail_ge', $data);
    }

    public function gePdf($ge_no){

        $data['invoiceData'] = DB::table('sales_ge')
                            ->where('ge_no', '=', $ge_no)
                            ->select("sales_ge.*")
                            ->first();
                            
        $data['customerInfo']  = DB::table('sales_ge')
                             ->where('sales_ge.ge_no',$ge_no)
                             ->leftjoin('debtors_master','debtors_master.debtor_no','=','sales_ge.debtor_no_ge')
                             ->leftjoin('cust_branch','cust_branch.branch_code','=','sales_ge.branch_id')
                             ->leftjoin('countries','countries.id','=','cust_branch.shipping_country_id')
                             ->select('debtors_master.debtor_no','debtors_master.name','debtors_master.phone','debtors_master.email','cust_branch.br_name','cust_branch.br_address','cust_branch.billing_street','cust_branch.billing_city','cust_branch.billing_state','cust_branch.billing_zip_code','countries.country','cust_branch.billing_country_id')                            
                             ->first();                          
                             

        $pdf = PDF::loadView('admin.invoice.invoiceGEPdf', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->download('ge_'.time().'.pdf',array("Attachment"=>0));
    }

    public function gePrint($ge_no){
        $data['invoiceData'] = DB::table('sales_ge')
                            ->where('ge_no', '=', $ge_no)
                            ->select("sales_ge.*")
                            ->first();

        $data['customerInfo']  = DB::table('sales_ge')
                             ->where('sales_ge.ge_no',$ge_no)
                             ->leftjoin('debtors_master','debtors_master.debtor_no','=','sales_ge.debtor_no_ge')
                             ->leftjoin('cust_branch','cust_branch.branch_code','=','sales_ge.branch_id')
                             ->leftjoin('countries','countries.id','=','cust_branch.shipping_country_id')
                             ->select('debtors_master.debtor_no','debtors_master.name','debtors_master.phone','debtors_master.email','cust_branch.br_name','cust_branch.br_address','cust_branch.billing_street','cust_branch.billing_city','cust_branch.billing_state','cust_branch.billing_zip_code','countries.country','cust_branch.billing_country_id')                            
                             ->first();   

        $pdf = PDF::loadView('admin.invoice.invoiceGEPdfPrint', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->stream('ge_'.time().'.pdf',array("Attachment"=>0));        
    }


      public function reporte(){
    
       

         $data['entregas'] = DB::table('sales_ge')
       ->leftjoin('debtors_master','sales_ge.debtor_no_ge','=','debtors_master.debtor_no')
        ->select("sales_ge.*", "debtors_master.*")->orderBy('ge_no', 'desc')
        ->get();     

        $pdf = PDF::loadView('admin.sale.reports.GuiaEntregaReport', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->stream('Factura'.time().'.pdf',array("Attachment"=>0));
    }



             // removendo o DebitoController
        public function destroy($id){
      
            
               $Guia=DB::table('sales_ge')->where('ge_no',$id)->first();

               $Delalhes_guia=DB::table('sales_ge_details')->where('ge_no_id',$id)->get();

               if($Guia->ge_no!=0){


                    \DB::table('sales_ge')->where('ge_no',$id)->delete();
                    \DB::table('sales_ge_details')->where('ge_no_id',$id)->delete();
                  
                  \Session::flash('success',trans('message.success.delete_success'));
                  return redirect()->intended('sales/guiaentrega');
               }

              \Session::flash('fail','');
               return redirect()->intended('sales/guiaentrega');

        
    }  




}
