<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Model\VD;

use App\Http\Requests;
use App\Model\Sales;
use Ap;
use DB;
use App\Model\SockMove;
use PDF;
use Session;
use Auth;
use App\Http\Start\Helpers;

class VDController extends Controller
{
    public function __construct(Auth $auth, VD $vd){ 
        $this->auth = $auth::user();
        $this->sale = $vd;
    }

        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_vd';
       
        $data['vendas'] = DB::table('sales_vd')
        ->leftjoin('debtors_master','sales_vd.debtor_no_vd','=','debtors_master.debtor_no')
        ->select("sales_vd.*","debtors_master.*")->orderBy('vd_no', 'desc')
        ->get();

        //$data['venda'] = DB::table('debtors_master')->where('status_vd','!=','anulado')->get();
        return view('admin.sale.sales_vd', $data);
    }

    public function create(){
    	$data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_vd';
        $data['customerData'] = DB::table('debtors_master')->where(['inactive'=>0])->get();
        $data['payments'] = DB::table('payment_terms')->get();
        $data['paymentTerms'] = DB::table('invoice_payment_terms')->get();
        $data['accounts'] = DB::table('bank_accounts')->where(['deleted'=>0])->pluck('account_name','id');

        $data['salesType'] = DB::table('sales_types')->select('sales_type','id')->get(); 

        $invoice_count = DB::table('sales_vd')->count();
        if($invoice_count>0){
        $invoiceReference = DB::table('sales_vd')->select('reference_vd')->orderBy('vd_no','DESC')->first();

        $ref = explode("-",$invoiceReference->reference_vd);
        $data['invoice_count'] = (int) $ref[1];
        }else{
            $data['invoice_count'] = 0 ;
        }

        $taxTypeList = DB::table('item_tax_types')->get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id[]'>";
        $selectEndCustom = "</select>";

        
        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='".$value->id."' taxrate='".$value->tax_rate."'>".$value->name.'('.$value->tax_rate.')'."</option>";          
        }
        $data['tax_type'] = $selectStart.$taxOptions.$selectEnd;
        $data['tax_type_custom'] = $selectStartCustom.$taxOptions.$selectEndCustom;

        $data['locData'] = DB::table('location')->get();
       
    	return view('admin.sale.vd_add', $data);
    }



    public function store(Request $request)
    {
    	
       // / return $request->all();

        $userId = \Auth::user()->id;
        $this->validate($request, [
            'reference'=>'required|unique:sales_orders',
            'ord_date' => 'required',
            'debtor_no' => 'required',
            'payment_id' => 'required',
            'account_no' => 'required',
        ]);

        require_once './conexao.php';

        $itemQuantity = $request->item_quantity;        
        $itemIds = $request->item_id;
        $itemDiscount = $request->discount;
        $taxIds = $request->tax_id;
        $unitPrice = $request->unit_price;
        $stock_id = $request->stock_id;
        $description = $request->description;

        $debtor_no = $_POST["debtor_no"];
        $data_vd = $_POST["ord_date"];
        $ref_vd = $_POST["reference"];
        $payment_id = $_POST["payment_id"];
        $account_no = $_POST["account_no"];
        $comments = $_POST["comments"];
        $total = $_POST["total"];

        $data1 = substr($data_vd, 0, 2);
        $data2 = substr($data_vd, 3, 2);
        $data3 = substr($data_vd, 6, 4);
        if($data1 > 10){
            $data_final = $data3."-". + $data2."-". + $data1; 
        }else{
            $data_final = $data3."-". + $data2."-0". + $data1;
        }

        $sql = "insert into sales_vd(debtor_no_vd, account_no, reference_vd, comments, vd_date, payment_id, total) values (:debtor_no_vd, :account_no, :reference_vd, :comments, :vd_date, :payment_id, :total)";
        $comando = $pdo->prepare($sql);
        $comando->bindParam(":debtor_no_vd", $debtor_no);
        $comando->bindParam(":account_no", $account_no);
        $comando->bindParam(":reference_vd", $ref_vd);
        $comando->bindParam(":comments", $comments);
        $comando->bindParam(":vd_date", $data_final);
        $comando->bindParam(":payment_id", $payment_id);        
        $comando->bindParam(":total", $total);     
        if($comando->execute()){
        	$last_id = $pdo->lastInsertId();
        	//echo 'sucesso1';
        }

             //nova funcao by sh@dy
        if(!empty($description)){
            foreach ($description as $key => $item) {
         
            $salesOrderDetail['vd_no'] = $last_id;
            $salesOrderDetail['description'] = $description[$key];
            $salesOrderDetail['quantity'] = $itemQuantity[$key];
            $salesOrderDetail['discount_percent'] = $itemDiscount[$key];
            $salesOrderDetail['tax_type_id'] = $taxIds[$key];
            $salesOrderDetail['unit_price'] = $unitPrice[$key];
           

             if($stock_id[$key]!="zero"){
                $salesOrderDetail['stock_id'] = $stock_id[$key];
                $salesOrderDetail['is_inventory'] = 1;
                 
            }else{
                $salesOrderDetail['is_inventory'] = 0;
                
            }
           DB::table('sales_details_vd')->insertGetId($salesOrderDetail);
            
            if($stock_id[$key]!="zero"){
                // create stockMove 
                $stockMove['stock_id'] = $stock_id[$key];
                //$stockMove['loc_code'] = 'PL';
                $stockMove['loc_code'] = $request->from_stk_loc;
                $stockMove['tran_date'] = DbDateFormat($request->ord_date);
                $stockMove['person_id'] = $userId;
                $stockMove['reference'] = 'store_out_'.$last_id;
                $stockMove['transaction_reference_id'] =$last_id;
                $stockMove['qty'] = '-'.$itemQuantity[$key];
                $stockMove['trans_type'] = SALESINVOICE;
                $stockMove['order_no'] = $last_id;
                $stockMove['order_reference'] = $request->reference;
                DB::table('stock_moves')->insertGetId($stockMove);
                }

            }
        }
        // Transaction Table

        

        $data['account_no'] = $request->account_no;//
        $data['trans_date'] = DbDateFormat($request->ord_date);//
        $data['description'] = $request->paymntFor;//
        $data['amount'] = abs($request->total);//
        $data['category_id'] = '1';
        $data['person_id'] = $this->auth->id;
        $data['trans_type'] = 'cash-in-by-sale';//
        $data['payment_method'] = $request->payment_id;
        $data['created_at'] = date("Y-m-d H:i:s");//
        $transactionId = DB::table('bank_trans')->insertGetId($data);




        if(!empty($last_id)){
            \Session::flash('success',trans('message.success.save_success'));
            return redirect()->intended('invoice/view-detail-vd/'.$last_id);
        }


    }



    public function viewVDDetails($vdId){
        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_vd';

        $data['saleDataOrder'] = DB::table('sales_vd')
                            ->where('vd_no', '=', $vdId)
                            ->select("sales_vd.*")
                            ->first();
        //$data['invoiceType'] = $data['saleDataOrder']->invoice_type;

        $data['saleDataInvoice'] = DB::table('sales_vd')
                    ->where('vd_no', '=', $vdId)
                    ->select("sales_vd.*")
                    ->first(); 

        $data['invoiceData'] = DB::table('sales_vd')
        ->leftJoin('sales_details_vd','sales_details_vd.vd_no','=','sales_vd.vd_no')
        ->where('sales_vd.vd_no', '=', $vdId)
                    ->select("sales_vd.*", "sales_details_vd.*")
                    ->get();
       

        
        

        $data['orderInfo']  = DB::table('sales_vd')->where('vd_no',$vdId)->select('reference_vd','vd_no')->first();

        $data['payments']   = DB::table('payment_terms')->get();
        

        //$data['invoice_no'] = $invoiceNo;
        
        $data['invoiced_status'] = 'yes';
        //$data['invoiced_date'] = $data['saleDataInvoice']->ord_date;

       
        
        $data['accounts'] = DB::table('bank_accounts')->pluck('account_name','id');
        $data['incomeCategories'] = DB::table('income_expense_categories')
                                    ->where('type','income')
                                    ->orWhere('type','no')
                                    ->pluck('name','id');


                $invoice_count = DB::table('payment_history')->count();
                if($invoice_count>0){
                    $invoiceReference = DB::table('payment_history')->select('reference')->orderBy('id','DESC')->first();

                   $ref = explode("-",$invoiceReference->reference);
                   $data['invoice_count'] = (int) $ref[1];
                }else{
                   $data['invoice_count'] = 0 ;
                }
        
        $data['venda'] = DB::table('sales_vd')
        ->leftjoin('debtors_master','sales_vd.debtor_no_vd','=','debtors_master.debtor_no')
        ->select("sales_vd.*","debtors_master.*")->where('vd_no', '=',$vdId)->orderBy('debtor_no', 'desc')
        ->first();
       


        return view('admin.invoice.viewVDDetails', $data);
    }


    public function vdPdf($vdId){

        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_vd';

        $data['saleDataOrder'] = DB::table('sales_vd')
                            ->where('vd_no', '=', $vdId)
                            ->select("sales_vd.*")
                            ->first();
        //$data['invoiceType'] = $data['saleDataOrder']->invoice_type;

        $data['saleDataInvoice'] = DB::table('sales_vd')
                    ->where('vd_no', '=', $vdId)
                    ->select("sales_vd.*")
                    ->first(); 

        $data['invoiceData'] = DB::table('sales_vd')
        ->leftJoin('sales_details_vd','sales_details_vd.vd_no','=','sales_vd.vd_no')
        ->where('sales_vd.vd_no', '=', $vdId)
                    ->select("sales_vd.*", "sales_details_vd.*")
                    ->get();
       
       $data['accounts'] = DB::table('bank_accounts')->pluck('account_name','id');
        $data['incomeCategories'] = DB::table('income_expense_categories')
                                    ->where('type','income')
                                    ->orWhere('type','no')
                                    ->pluck('name','id');

        
        

        $data['orderInfo']  = DB::table('sales_vd')->where('vd_no',$vdId)->select('reference_vd','vd_no')->first();

        $data['payments']   = DB::table('payment_terms')->get();

        $pdf = PDF::loadView('admin.invoice.vdPDF', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->download('vd_'.time().'.pdf',array("Attachment"=>0));
    }

    public function vdPrint($vdId){
        $data['saleDataOrder'] = DB::table('sales_vd')
                            ->where('vd_no', '=', $vdId)
                            ->select("sales_vd.*")
                            ->first();

        $data['saleDataInvoice'] = DB::table('sales_vd')
                    ->where('vd_no', '=', $vdId)
                    ->select("sales_vd.*")
                    ->first(); 

        $data['invoiceData'] = DB::table('sales_vd')
        ->leftJoin('sales_details_vd','sales_details_vd.vd_no','=','sales_vd.vd_no')
        ->where('sales_vd.vd_no', '=', $vdId)
                    ->select("sales_vd.*", "sales_details_vd.*")
                    ->get();
       
       $data['accounts'] = DB::table('bank_accounts')->pluck('account_name','id');
        $data['incomeCategories'] = DB::table('income_expense_categories')
                                    ->where('type','income')
                                    ->orWhere('type','no')
                                    ->pluck('name','id');
        $data['orderInfo']  = DB::table('sales_vd')->where('vd_no',$vdId)->select('reference_vd','vd_no')->first();

        $data['payments']   = DB::table('payment_terms')->get();


        $pdf = PDF::loadView('admin.invoice.vdPDFPrint', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->stream('vd_'.time().'.pdf',array("Attachment"=>0));        
    }



      public function reporte(){


         $data['vendas'] = DB::table('sales_vd')
       ->leftjoin('debtors_master','sales_vd.debtor_no_vd','=','debtors_master.debtor_no')
        ->select("sales_vd.*", "debtors_master.*")->orderBy('vd_no', 'desc')
        ->get();     

        $pdf = PDF::loadView('admin.sale.reports.VDReport', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->stream('GuiaTransporte'.time().'.pdf',array("Attachment"=>0));
    }



        //Funcao para actualizar os estado da factura
        public function editStatus($id,Request $request){

            $result=DB::table('sales_vd')->where('vd_no', $id)->first();

            $texto_vd="Payment for ".$result->reference_vd;
            $descricao_tra="Cancel VD ".$result->reference_vd;

            //actualizar a vd
            $vendaDinheiro['status_vd'] = 'Anulado';
            $vendaDinheiro['sales_vd_description'] =$request->description;
            DB::table('sales_vd')->where('vd_no', $id)->update($vendaDinheiro);
            

           $UpdateStock=SockMove::where("order_no","=",$id)->get();

            if($UpdateStock!=null){

                foreach ($UpdateStock as $UpdateStocks) {
                  if($UpdateStocks->stock_id!='zero'){
                        DB::table('stock_moves')
                        ->where('order_no', $id)
                        ->update(['qty' => 0]);     

                    }

                }
             } 
             //
            //return $UpdateStock=SockMove::where("order_no","=",$id)->get();
            $transaFirst = DB::table('bank_trans')->where('description', $texto_vd)->first();
            //"Payment for VD-0001/2018";
            // Transaction Table
            $valor=$transaFirst->amount*(-1);

            $data['account_no'] = $transaFirst->account_no;//
            $data['trans_date'] = DbDateFormat($transaFirst->trans_date);//
            $data['description'] = $descricao_tra;//
            $data['amount'] =$valor;//
            $data['category_id'] = '1';
            $data['person_id'] = $this->auth->id;
            $data['trans_type'] = 'cash-in-by-sale';//
            $data['payment_method'] =$transaFirst->payment_method;
            $data['created_at'] = date("Y-m-d H:i:s");//
            $transactionId = DB::table('bank_trans')->insertGetId($data);
        
            \Session::flash('success',trans('message.success.save_success'));
             return redirect()->intended('invoice/view-detail-vd/'.$id);
    }



     public function destroy($id)
    {
       
        if(isset($id)) {
           
           // CONDICOES PARA APAGAR
            // verficar se esta anulada ou nao a venda 
           $result=DB::table('sales_vd')->where('vd_no', $id)->first();
           $texto_vd="Payment for ".$result->reference_vd;

            if($result->status_vd=="Anulado"){
                //return "venda Cancelada sera apagada";
                //Apagar os rastos de pagamento da factura

                $descricao_tra="Cancel VD ".$result->reference_vd;
                
                \DB::table('bank_trans')->where('description', $texto_vd)->delete();
                \DB::table('bank_trans')->where('description', $descricao_tra)->delete();
                \DB::table('sales_vd')->where('vd_no', $id)->delete();

                \Session::flash('success',trans('message.success.delete_success'));
                return redirect()->intended('sales/vd');

            }else{
            
                //return "venda nao no estado normal deve ser feito o rollback de tudo feito";
                $UpdateStock=SockMove::where("order_no","=",$id)->get();
                if($UpdateStock!=null){

                    foreach ($UpdateStock as $UpdateStocks) {
                      if($UpdateStocks->stock_id!='zero'){
                            DB::table('stock_moves')
                            ->where('order_no', $id)->delete();
                            //->update(['qty' => 0]);     

                        }

                    }
                 } 
                 \DB::table('bank_trans')->where('description', $texto_vd)->delete(); 
                  \DB::table('sales_vd')->where('vd_no', $id)->delete();

                \Session::flash('success',trans('message.success.delete_success'));
                return redirect()->intended('sales/vd');

                
            }
           
        }
    }




}
