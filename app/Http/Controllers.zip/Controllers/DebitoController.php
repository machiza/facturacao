<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Debitos;
use App\Http\Requests;
use App\Model\Creditos;
use App\Model\Credito;
use App\Model\SaleCC;
use App\Model\SockMove;
use App\Model\SalePending;
use DB;
use PDF;
use App\Http\Start\Helpers;

class DebitoController extends Controller
{
    public function __construct(Debitos $debitos){
     /**
     * Set the database connection. reference app\helper.php
     */   
        //selectDatabase();
        $this->sale = $debitos;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_debito';
        
         $data['debitos'] = DB::table('sales_debito')
        ->leftjoin('sales_orders','sales_debito.order_no_id','=','sales_orders.order_no')
        ->leftjoin('debtors_master','sales_debito.debtor_no_debit','=','debtors_master.debtor_no')
        ->select("sales_orders.*", "sales_debito.*","debtors_master.*")->orderBy('debit_no', 'desc')
        ->get();

        $data['Total_por_pagar'] = DB::table('sales_debito')->sum('debito');   
        $data['pago'] = DB::table('sales_debito')->sum('paid_amount_debit');   
        $data['saldo'] = $data['Total_por_pagar']-$data['pago'];


            //admin.sale.sales_debito
        return view('admin.sale.Sales_debito', $data);
        //return 'Sucesso';
    }

    public function getInvoices(){
        require './conexao.php';
        $sql = "Select * from sales_orders where invoice_type = 'directInvoice' and debtor_no = '" . $_POST["debtor_no"] . "'";
        $comando = $pdo->prepare($sql);
        $comando->execute();
        $row = $comando->rowCount();
        if($row >= 1){
            echo "<option value=''>". trans('message.form.select_ones') ."</option>";
            while ($rs = $comando->fetch()){
                    $id = $rs ["order_no"];
                    $ref = $rs ["reference"];
                    echo "<option value='$id'>$ref</option>";
            }
        }else{
            echo "<option value=''>". trans('message.form.no_invoice') ."</option>";
        }
    }

    public function create(){

        $data['menu'] = 'sales';
        $data['sub_menu'] = 'sales/direct-invoice_debito';
        $data['customerData'] = DB::table('debtors_master')->where(['inactive'=>0])->where('status_debtor','!=','desactivo')->get();

        $data['salesData'] = DB::table('sales_orders')->where('trans_type',SALESINVOICE)->get();

        $data['locData'] = DB::table('location')->get();
        $data['payments'] = DB::table('payment_terms')->get();
        //d($data['payments'],1);
        $data['paymentTerms'] = DB::table('invoice_payment_terms')->get();
        $invoice_count = DB::table('sales_debito')->count();
        
        $data['salesType'] = DB::table('sales_types')->select('sales_type','id')->get();        
        
        if($invoice_count>0){
        $invoiceReference = DB::table('sales_debito')->select('reference_debit')->orderBy('debit_no','DESC')->first();

         $ref = explode("-",$invoiceReference->reference_debit);
        $data['invoice_count'] = (int) $ref[1];
        }else{
            $data['invoice_count'] = 0 ;
        }
        
        $taxTypeList = DB::table('item_tax_types')->get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id[]'>";
        $selectEndCustom = "</select>";

        
        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='".$value->id."' taxrate='".$value->tax_rate."'>".$value->name.'('.$value->tax_rate.')'."</option>";          
        }
        $data['tax_type'] = $selectStart.$taxOptions.$selectEnd;
        $data['tax_type_custom'] = $selectStartCustom.$taxOptions.$selectEndCustom;

        return view('admin.sale.debit_add', $data);
    }

    /**
     * Store a newly created resource in storage.
     **/

    public function store(Request $request)
        {
            require_once './conexao.php';
          //  return $request->reference_debit;

            //reference_order_fact":"228"
            //reference_order_fact":"228

             //$Sallacc= new Sallacc;
            // $Sallacc->  


            /*
            {"_token":"ZGd1QgkxOgV79bY2x8tmkUeWHFU0FJGdzztyriSn","debtor_no":"15","reference_order_fact":"226","from_stk_loc":"PL","payment_id":"2","payment_term":"1","sales_type":"1","ord_date":"19-02-2018","reference_debit":"ND-0002\/2018","stock_id":["003","001","zero"],"description":["IPHONE 6 Plus","Iphone 6","Servi\u00e7o de instala\u00e7\u00e3o de redes de computadores"],"item_quantity":["4","1","1"],"item_id":["19","17","zero"],"unit_price":["3000","5000","0"],"tax_id":["1","1","1"],"discount":["0","0","0"],"item_price":["12000","5000","0"],"total":"17000","comments":"","btn_add_debito":""}*/



            $userId = \Auth::user()->id;
            $itemQuantity = $request->item_quantity;        
            $itemIds = $request->item_id;
            $itemDiscount = $request->discount;
            $taxIds = $request->tax_id;
            $unitPrice = $request->unit_price;
            $stock_id = $request->stock_id;
            $description = $request->description;

            $ord_date = $request->ord_date;

            $data_final="";
            $data1 = substr($ord_date, 0, 2);
            $data2 = substr($ord_date, 3, 2);
            $data3 = substr($ord_date, 6, 4);
            if($data1 > 10){
               $data_final = $data3."-". + $data2."-". + $data1; 
            }else{
               $data_final = $data3."-". + $data2."-0". + $data1;
            }

            $invoice_type_credit = 'directInvoice';
            $trans_type_credit_indirect = 201;

            /*
            $NovaOrdem= new Credito;
            $NovaOrdem->credito=$request->total;
            $NovaOrdem->order_no_id=$request->reference_order_fact;
            $NovaOrdem->credit_date=$data_final;
            $NovaOrdem->trans_type_credit=$trans_type_credit_indirect;
            $NovaOrdem->debtor_no_credit=$request->debtor_no;
            $NovaOrdem->person_id_credit=$userId;
            $NovaOrdem->reference_credit=$request->reference_credit;
           // $NovaOrdem->order_reference_id_credit=$request->
           // $NovaOrdem->order_reference_credit=$request->
            $NovaOrdem->invoice_type_credit=$invoice_type_credit;
            $NovaOrdem->from_stk_loc=$request->from_stk_loc;
            $NovaOrdem->payment_id_credit=$request->payment_id;
           // $NovaOrdem->paid_amount_credit=$request->
            $NovaOrdem->payment_term_credit=$request->payment_term;
            $NovaOrdem->save();
                */

            $NovaOrdem['debito'] = $request->total;
            if($request->reference_order_fact!=""){
                $NovaOrdem['order_no_id'] = $request->reference_order_fact;
            }
            $NovaOrdem['debit_date'] =  $data_final;
            $NovaOrdem['trans_type_debit'] =$trans_type_credit_indirect;
            $NovaOrdem['debtor_no_debit'] = $request->debtor_no;
            $NovaOrdem['person_id_debit'] = $userId;
            $NovaOrdem['reference_debit'] = $request->reference_debit;
            $NovaOrdem['invoice_type_debit'] = $invoice_type_credit;
            $NovaOrdem['from_stk_loc'] = $request->from_stk_loc;;            
            $NovaOrdem['payment_id_debit'] = $request->payment_id;         
            $NovaOrdem['payment_term_debit'] =$request->payment_term;           

            $NrNotaDebito= DB::table('sales_debito')->insertGetId($NovaOrdem);


            //$NrNotaCredito//debit_no
            //$NovaOrdem->credito_no

            $saida = "1";
            $TabelaCC= new SaleCC;
            $TabelaCC->debtor_no_doc=$request->debtor_no;
            if($request->reference_order_fact!=""){
            $TabelaCC->order_no_doc=$NrNotaDebito;
            }
            $TabelaCC->credit_no_doc=$NrNotaDebito;
            $TabelaCC->reference_doc=$NovaOrdem['reference_debit'];
            //$TabelaCC->order_reference_doc= $NovaOrdem->order_reference_credit;
            $TabelaCC->saldo_doc=$request->total;
            $TabelaCC->amount_doc=$request->total;
            $TabelaCC->debito_credito=$saida;
            $TabelaCC->ord_date_doc=$data_final;
            $TabelaCC->save();

             $NovoSalePeding=new SalePending();
             $NovoSalePeding->debtor_no_pending=$request->debtor_no;
            if($request->reference_order_fact!=""){
            $NovoSalePeding->order_no_pending=$NovaOrdem['order_no_id'];
            }
             $NovoSalePeding->reference_pending=$NovaOrdem['reference_debit'];
             $NovoSalePeding->amount_total_pending=$request->total;
             $NovoSalePeding->ord_date_pending=$data_final;
             $NovoSalePeding->save();



               /* if($request->reference_order_fact!=""){

                    return 'Com factura';
                }else{

                   return "Nocredito eh ".$NrNotaCredito;
                }  
                */

                // Inventory Items Start
                if(!empty($description)){
                    foreach ($description as $key => $item) {
                    // create salesOrderDetail Start order_reference_id
                    $salesOrderDetail['order_no'] = $NrNotaDebito;
                    $salesOrderDetail['stock_id'] = $stock_id[$key];
                    $salesOrderDetail['description'] = $item;
                    $salesOrderDetail['quantity'] = $itemQuantity[$key];
                    $salesOrderDetail['trans_type'] = SALESORDER;
                    $salesOrderDetail['discount_percent'] = $itemDiscount[$key];
                    $salesOrderDetail['tax_type_id'] = $taxIds[$key];
                    $salesOrderDetail['unit_price'] = $unitPrice[$key];
                    $salesOrderDetail['tipo_operacao'] = 'debito';
                    // $salesOrderDetail['is_inventory'] = 1;
                    

                     if($stock_id[$key]=="zero"){
                        $salesOrderDetail['is_inventory'] = 0;
                    }
                    else{
                         $salesOrderDetail['is_inventory'] = 1;
                    }

                    DB::table('sales_order_details')->insertGetId($salesOrderDetail);
                    
                    // create stockMove
                    if($stock_id[$key]!="zero"){

                        
                      /*  if($request->reference_order_fact!=""){
                       // return $UpdateStock=SockMove::all();
                    $facturaNumero=$request->reference_order_fact-1;
                    $UpdateStock=SockMove::where("order_no","=",$request->reference_order_fact-1)->where('stock_id','=',$stock_id[$key])->first();
                             if($UpdateStock!=null){
                               $valor= $UpdateStock->qty=$UpdateStock->qty+$itemQuantity[$key];
                                $sql_paid_doc = "update stock_moves set qty = :quantidade where stock_id = :stock and order_no =:numero " ;
                                $comando_paid_doc = $pdo->prepare($sql_paid_doc);
                                $comando_paid_doc->bindParam(":quantidade", $valor);
                                $comando_paid_doc->bindParam(':stock', $stock_id[$key]);
                                $comando_paid_doc->bindParam(':numero',$facturaNumero );
                                $comando_paid_doc->execute();
                             }  
                            }else{ 
                                    $stockMove['stock_id'] = $stock_id[$key];
                                    $stockMove['loc_code'] = $request->from_stk_loc;
                                   // $stockMove['tran_date'] = DbDateFormat($request->ord_date);
                                    $stockMove['person_id'] = $userId;
                                    $stockMove['reference'] = 'store_out_'.$NrNotaDebito;
                                  //  $stockMove['transaction_reference_id'] =$order_reference_id2;
                                    $stockMove['qty'] =$itemQuantity[$key];
                                    $stockMove['trans_type'] = SALESINVOICE;
                                   // $stockMove['order_no'] = $order_reference_id;
                                   // $stockMove['order_reference'] = $order_reference_Gamb;

                                    //Restar
                                    DB::table('stock_moves')->insertGetId($stockMove);     

                            }
                           */

                                $stockMove['stock_id'] = $stock_id[$key];
                                $stockMove['order_no'] = $NrNotaDebito;
                                $data['tran_date'] = date("Y-m-d H:i:s");//
                                $stockMove['loc_code'] = $request->from_stk_loc;
                                $stockMove['person_id'] = $userId;
                                $stockMove['reference'] = 'store_out_'.$NrNotaDebito;
                                $stockMove['order_reference'] =$NovaOrdem['reference_debit'];
                                $stockMove['qty'] = '-'.$itemQuantity[$key];
                                $stockMove['trans_type'] = SALESINVOICE;
                                DB::table('stock_moves')->insertGetId($stockMove);       

                    }
                }
         }       

              // Create salesOrder Invoice end
                        \Session::flash('success',trans('message.success.save_success'));
                        return redirect()->intended('invoice/view-detail-invoice-debito/'.$NrNotaDebito);
    }       



    public function storeOlder(Request $request)
    {
        $userId = \Auth::user()->id;
        $itemQuantity = $request->item_quantity;        
        $itemIds = $request->item_id;
        $itemDiscount = $request->discount;
        $taxIds = $request->tax_id;
        $unitPrice = $request->unit_price;
        $stock_id = $request->stock_id;
        $description = $request->description;

        //echo $description;

        require_once './conexao.php';

        $reference = $_POST["reference_order_fact"];

        $sql_debito = "Select * from sales_debito
                inner join sales_orders on sales_debito.order_no_id=sales_orders.order_no
                inner join debtors_master on debtors_master.debtor_no=sales_orders.debtor_no where order_no='$reference'";
        $comando_debito = $pdo->prepare($sql_debito);
        if($comando_debito->execute()){
            $rs_comando_debito = $comando_debito->fetch();
            if($comando_debito->rowCount() == 0){
                $trans_type_debit = 202;
            }else{
                $trans_type_debit = $rs_comando_debito ["trans_type"];
            }           

            $reference_debit = $_POST["reference_debit"];
            
            $debtor_no = $_POST["debtor_no"];
            $ord_date = $_POST["ord_date"];
            $total_tax = $_POST["total"];
            $total = $_POST["total"];

            $payment_id = $_POST["payment_id"];
            $payment_term = $_POST["payment_term"];

            $from_stk_loc = $_POST["from_stk_loc"];

            $comments =  $_POST["comments"];

            $data1 = substr($ord_date, 0, 2);
            $data2 = substr($ord_date, 3, 2);
            $data3 = substr($ord_date, 6, 4);
            if($data1 > 10){
               $data_final = $data3."-". + $data2."-". + $data1; 
            }else{
               $data_final = $data3."-". + $data2."-0". + $data1;
            }

            
            $invoice_type_debit = 'indirectOrder';
            $trans_type_debit_indirect = 201;

            // create salesOrder start
            $insert_indirect = "insert into sales_debito
                      (debito, order_no_id, debit_date, trans_type_debit, debtor_no_debit, person_id_debit, invoice_type_debit, from_stk_loc, payment_id_debit)
                      values
                      (:debito, :order_fact, :data, :trans_type_debit, :debtor_no, :person_id, :invoice_type_debit, :from_stk_loc, :payment_id)";

            $referenc = $reference - 1;

            $comando_insert_indirect = $pdo->prepare($insert_indirect);
            $comando_insert_indirect->bindParam(":debito", $total);
            $comando_insert_indirect->bindParam(":order_fact", $referenc);
            $comando_insert_indirect->bindParam(":data", $data_final);
            $comando_insert_indirect->bindParam(":trans_type_debit", $trans_type_debit_indirect);
            $comando_insert_indirect->bindParam(":debtor_no", $debtor_no);
            $comando_insert_indirect->bindParam(":person_id", $userId);
            $comando_insert_indirect->bindParam(":invoice_type_debit", $invoice_type_debit);
            $comando_insert_indirect->bindParam(":from_stk_loc", $from_stk_loc);
            $comando_insert_indirect->bindParam(":payment_id", $payment_id);
            if($comando_insert_indirect->execute()){
  
                //gmb: pega uma ordem (cot) indirect nos debitos:
                $sql_debito_lastGamb = "Select * from sales_debito
                inner join sales_orders on sales_debito.order_no_id=sales_orders.order_no
                inner join debtors_master on debtors_master.debtor_no=sales_orders.debtor_no
                where invoice_type_debit = 'indirectOrder'";
                $comando_debito_lastGamb = $pdo->prepare($sql_debito_lastGamb);
                if($comando_debito_lastGamb->execute()){
                    $rs_comando_debito_lastGamb = $comando_debito_lastGamb->fetch();
                    $order_reference_Gamb = $rs_comando_debito_lastGamb ["reference"];

                    $sql_debito_last = "Select * from sales_debito order by debit_no DESC LIMIT 1";
                    $comando_debito_last = $pdo->prepare($sql_debito_last);
                    if($comando_debito_last->execute()){
                         $rs_comando_debito_last = $comando_debito_last->fetch();
                       //order_reference_id:
                       $order_reference_id = $rs_comando_debito_last ["debit_no"];
                       // create salesOrder end

                        // Create salesOrder Invoice start
                        $invoice_type_debit_direct = 'directInvoice';
                        $insert = "insert into sales_debito (debito, order_no_id, debit_date, trans_type_debit, debtor_no_debit, person_id_debit, reference_debit, order_reference_id_debit, order_reference_debit, invoice_type_debit, from_stk_loc, payment_id_debit, payment_term_debit, comments) values (:debito, :order_fact, :data, :trans_type_debit, :debtor_no, :person_id, :reference_debit, :order_reference_id, :order_reference_debit, :invoice_type_debit, :from_stk_loc, :payment_id, :payment_term, :comments)";
                        $comando_insert = $pdo->prepare($insert);
                        $comando_insert->bindParam(":debito", $total);
                        $comando_insert->bindParam(":order_fact", $reference);
                        $comando_insert->bindParam(":data", $data_final);
                        $comando_insert->bindParam(":trans_type_debit", $trans_type_debit);
                        $comando_insert->bindParam(":debtor_no", $debtor_no);
                        $comando_insert->bindParam(":person_id", $userId);
                        $comando_insert->bindParam(":reference_debit", $reference_debit);
                        $comando_insert->bindParam(":order_reference_id", $order_reference_id);//id cot indirect
                        $comando_insert->bindParam(":order_reference_debit", $order_reference_Gamb);//ref cot indirecta
                        $comando_insert->bindParam(":invoice_type_debit", $invoice_type_debit_direct);
                        $comando_insert->bindParam(":from_stk_loc", $from_stk_loc);
                        $comando_insert->bindParam(":payment_id", $payment_id);
                        $comando_insert->bindParam(":payment_term", $payment_term);
                        $comando_insert->bindParam(":comments", $comments);
                        if($comando_insert->execute()){

                            //cc
                            $sql_last_debit = "Select * from sales_debito order by debit_no DESC LIMIT 1";
                            $comando_last_debit = $pdo->prepare($sql_last_debit);
                            if($comando_last_debit->execute()){
                                $id_deb = $comando_last_debit->fetch();
                                $ord_deb = $id_deb["order_no_id"];
                                $ref_deb = $id_deb["reference_debit"];
                                $order_ref_fact = $id_deb["order_reference_debit"];
                                $insert_doc = "insert into sales_cc (debtor_no_doc, order_no_doc, debit_no_doc, reference_doc, order_reference_doc, amount_doc, saldo_doc,  ord_date_doc) values (:debtor_no_doc, :order_no_doc, :debit_no_doc, :reference_doc, :order_reference_doc, :amount_doc, :saldo_doc, :ord_date_doc)";
                                $comando_update_deb = $pdo->prepare($insert_doc);
                                $comando_update_deb->bindParam(":debtor_no_doc", $debtor_no);
                                $comando_update_deb->bindParam(":order_no_doc", $ord_deb);
                                $comando_update_deb->bindParam(":debit_no_doc", $id_deb["debit_no"]);
                                $comando_update_deb->bindParam(":reference_doc", $ref_deb);
                                $comando_update_deb->bindParam(":order_reference_doc", $order_ref_fact);
                                $comando_update_deb->bindParam(":amount_doc", $total);
                                $comando_update_deb->bindParam(":saldo_doc", $total);
                                $comando_update_deb->bindParam(":ord_date_doc", $data_final);
                                $comando_update_deb->execute();
                            }
                            //end cc

                            //pending
                            $sql_last_debit = "Select * from sales_debito order by debit_no DESC LIMIT 1";
                            $comando_last_debit = $pdo->prepare($sql_last_debit);
                            if($comando_last_debit->execute()){
                                $id_deb = $comando_last_debit->fetch();
                                $ord_deb = $id_deb["order_no_id"];
                                $ref_deb = $id_deb["reference_debit"];
                                $insert_pending = "insert into sales_pending (debtor_no_pending, order_no_pending, reference_pending, amount_total_pending,  ord_date_pending) values (:debtor_no_pending, :order_no_pending, :reference_pending, :amount_total_pending, :ord_date_pending)";
                                $comando_update_pending = $pdo->prepare($insert_pending);
                                $comando_update_pending->bindParam(":debtor_no_pending", $debtor_no);
                                $comando_update_pending->bindParam(":order_no_pending", $ord_deb);
                                $comando_update_pending->bindParam(":reference_pending", $ref_deb);
                                $comando_update_pending->bindParam(":amount_total_pending", $total);
                                $comando_update_pending->bindParam(":ord_date_pending", $data_final);
                                $comando_update_pending->execute();
                            }
                            //end pending

                            $sql_debito_last2 = "Select * from sales_debito order by debit_no DESC LIMIT 1";
                            $comando_debito_last2 = $pdo->prepare($sql_debito_last2);
                            if($comando_debito_last2->execute()){
                                $rs_comando_debito_last2 = $comando_debito_last2->fetch();
                                //order_reference_id:
                                $order_reference_id2 = $rs_comando_debito_last2 ["debit_no"];

                                // Inventory Items Start
                                if(!empty($description)){
                                    foreach ($description as $key => $item) {
                                    // create salesOrderDetail Start
                                    $salesOrderDetail['order_no'] = $order_reference_id;
                                    $salesOrderDetail['stock_id'] = $stock_id[$key];
                                    $salesOrderDetail['description'] = $item;
                                    $salesOrderDetail['quantity'] = $itemQuantity[$key];
                                    $salesOrderDetail['trans_type'] = SALESORDER;
                                    $salesOrderDetail['discount_percent'] = $itemDiscount[$key];
                                    $salesOrderDetail['tax_type_id'] = $taxIds[$key];
                                    $salesOrderDetail['unit_price'] = $unitPrice[$key];
                                   

                                    if($stock_id[$key]!="zero"){
                                    $salesOrderDetail['is_inventory'] = 1;
                                    }else{
                                        $salesOrderDetail['is_inventory'] = 0;
                                    }
                                    DB::table('sales_order_details')->insertGetId($salesOrderDetail);
            
                                    // Create salesOrderDetailInvoice Start
                                    $salesOrderDetailInvoice['order_no'] = $order_reference_id2;
                                    $salesOrderDetailInvoice['stock_id'] = $stock_id[$key];
                                    $salesOrderDetailInvoice['description'] = $description[$key];
                                    $salesOrderDetailInvoice['quantity'] = $itemQuantity[$key];
                                    $salesOrderDetailInvoice['trans_type'] = SALESINVOICE;
                                    $salesOrderDetailInvoice['discount_percent'] = $itemDiscount[$key];
                                    $salesOrderDetailInvoice['tax_type_id'] = $taxIds[$key];
                                    $salesOrderDetailInvoice['unit_price'] = $unitPrice[$key];
                                   
                                    
                                    
                                    if($stock_id[$key]!="zero"){
                                         $salesOrderDetailInvoice['is_inventory'] = 1;
                                    }else{
                                        $salesOrderDetailInvoice['is_inventory'] = 0;
                                    }
                                    DB::table('sales_order_details')->insertGetId($salesOrderDetailInvoice);
                                   // Create salesOrderDetailInvoice End

                                    // create stockMove 
                                     if($stock_id[$key]!="zero"){
                                            $stockMove['stock_id'] = $stock_id[$key];
                                            $stockMove['loc_code'] = $request->from_stk_loc;
                                            $stockMove['tran_date'] = DbDateFormat($request->ord_date);
                                            $stockMove['person_id'] = $userId;
                                            $stockMove['reference'] = 'store_out_'.$order_reference_id2;
                                            $stockMove['transaction_reference_id'] =$order_reference_id2;
                                            $stockMove['qty'] = '-'.$itemQuantity[$key];
                                            $stockMove['trans_type'] = SALESINVOICE;
                                            $stockMove['order_no'] = $order_reference_id;
                                            $stockMove['order_reference'] = $order_reference_Gamb;
                                            DB::table('stock_moves')->insertGetId($stockMove);
                                       }     
                                }
                            }


                            // Inventory Items End

                            //if($stock_id[$key]!="zero"){

                            /* Custom items
                            $tax_id_custom = $request->tax_id_custom;
                            $custom_items_discount = $request->custom_items_discount;
                            $custom_items_name = $request->custom_items_name;
                            $custom_items_rate = $request->custom_items_rate;
                            $custom_items_qty  = $request->custom_items_qty;
                            $custom_items_amount = $request->custom_items_amount;
                            // d($custom_items_name,1);
                            if(!empty($custom_items_name)){
          
                                foreach ($custom_items_name as $key=>$value) {
                                // custom item order detail
                                $itemsOrder['order_no'] = $order_reference_id;
                                $itemsOrder['trans_type'] = SALESORDER;
                                $itemsOrder['tax_type_id'] = $tax_id_custom[$key];
                                $itemsOrder['discount_percent'] = $custom_items_discount[$key];
                                $itemsOrder['description'] = $custom_items_name[$key];
                                $itemsOrder['unit_price'] = $custom_items_rate[$key];
                                $itemsOrder['quantity'] = $custom_items_qty[$key];
                                $itemsOrder['is_inventory'] = 0;
                                DB::table('sales_order_details')->insert($itemsOrder);   
                
                                // custom item invoice detail
                                $itemsInvoice['order_no'] = $order_reference_id2;//id do debit
                                $itemsInvoice['trans_type'] = SALESINVOICE;
                                $itemsInvoice['tax_type_id'] = $tax_id_custom[$key];
                                $itemsInvoice['discount_percent'] = $custom_items_discount[$key];
                                $itemsInvoice['description'] = $custom_items_name[$key];
                                $itemsInvoice['unit_price'] = $custom_items_rate[$key];
                                $itemsInvoice['quantity'] = $custom_items_qty[$key];
                                $itemsInvoice['is_inventory'] = 0;
                                DB::table('sales_order_details')->insert($itemsInvoice); 
                            }//end foeach itm
                        }//end  ust itm
                       
                        */

                        // Create salesOrder Invoice end
                        \Session::flash('success',trans('message.success.save_success'));
                        return redirect()->intended('invoice/view-detail-invoice-debito/'.$referenc.'/'.$reference);
                    }
                }}
            }//end gamb
        }//end insert indirect
        }
    }//end FUNCTION


        /**
    * Check reference no if exists
    */
    public function referenceValidation(Request $request){
        
        $data = array();
        $ref = $request['ref'];
        $result = DB::table('sales_debito')->where("reference_debit",$ref)->first();

        if(count($result)>0){
            $data['status_no'] = 1; 
        }else{
            $data['status_no'] = 0;
        }

        return json_encode($data);       
    }



      // repor
       public function reporte(){
       
         
       $data['debitos'] = DB::table('sales_debito')
        ->leftjoin('sales_orders','sales_debito.order_no_id','=','sales_orders.order_no')
        ->leftjoin('debtors_master','sales_debito.debtor_no_debit','=','debtors_master.debtor_no')
        ->select("sales_orders.*", "sales_debito.*","debtors_master.*")->orderBy('debit_no', 'desc')
        ->get();     

        /*$data['salesData'] = $this->sale->getAllSalseOrder($from = NULL, $to = NULL, $item = NULL, $customer = NULL, $location = NULL); */  

        $pdf = PDF::loadView('admin.sale.reports.debitoReport', $data);
        $pdf->setPaper(array(0,0,750,1060), 'portrait');
        return $pdf->stream('Factura'.time().'.pdf',array("Attachment"=>0));
    }



        // removendo o DebitoController
        public function destroy($id){
        //return "venda nao no estado normal deve ser feito o rollback de tudo feito";

                  // localizando a nota de debito                 
       // return    $Debito=DB::table('sales_debito')->where('debit_no', $id)->get(); 

        $Debito  = DB::table('sales_debito')
        ->leftjoin('sales_orders','sales_debito.order_no_id','=','sales_orders.order_no')
        ->leftjoin('debtors_master','sales_debito.debtor_no_debit','=','debtors_master.debtor_no')
        ->select("sales_orders.*", "sales_debito.*","debtors_master.*")->where('debit_no', $id)->first();
        
        //return $Debito->paid_amount_debit;

        if($Debito->paid_amount_debit!=0){

            \Session::flash('fail',trans('message.error.delete_debit'));
            return redirect()->intended('sales/debito');

         }else{   
              $UpdateStock=SockMove::where("order_no","=",$id)->get();
                if($UpdateStock!=null){

                    foreach ($UpdateStock as $UpdateStocks) {
                      if($UpdateStocks->stock_id!='zero'){
                            DB::table('stock_moves')
                            ->where('order_no', $id)->delete();
                            //->update(['qty' => 0]);     
                        }
                    }
                 } 
            
             // Abaixo querys perigosas    
                 
              

            // Funcao abaixo=>Eliminado os detalhes da Notacredito     
            \DB::table('sales_order_details')->where('order_no', $id)->where('tipo_operacao', 'debito')->delete(); 

            // eliminado na tabela CC
            \DB::table('sales_cc')->where('reference_doc', $Debito->reference_debit)->delete(); 

            // eliminado na tabela dos pendentes
            \DB::table('sales_pending')->where('reference_pending', $Debito->reference_debit)->delete(); 

            // eliminando a nota Debito
             \DB::table('sales_debito')->where('reference_debit', $Debito->reference_debit)->delete(); 
              
            \Session::flash('success',trans('message.success.delete_success'));
            return redirect()->intended('sales/debito');

        }
    }  

}
